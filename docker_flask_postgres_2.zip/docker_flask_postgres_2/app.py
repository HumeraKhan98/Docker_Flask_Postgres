#import requests
from flask import Flask, request,render_template, redirect, url_for
import psycopg2

app = Flask(__name__)

conn = None
cur = None
try:
    conn = psycopg2.connect(
        database="dockerdb",
        user="postgres",
        password="postgres",
        host="postgrescontainer"
    )
    cur = conn.cursor()

    create_script = '''CREATE TABLE IF NOT EXISTS students (
                            id      serial     PRIMARY KEY,
                            fname   varchar(40) NOT NULL,
                            email   varchar(40))'''
    cur.execute(create_script)

    conn.commit()

except Exception as error:
    print(error)
finally:
    if cur is not None:
        cur.close()
    if conn is not None:
        conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        a = request.form['u']
        b = request.form['a']

        conn = psycopg2.connect(
            database="dockerdb",
            user="postgres",
            password="postgres",
            host="postgrescontainer"
        )

        cur = conn.cursor()
        cur.execute('INSERT INTO students (fname,email)'
                        'VALUES (%s, %s)',
                        (a,b))
        conn.commit()
        cur.close()
        conn.close()

        return render_template("index.html", n=a, e=b)
    else:
        return "error"    

if __name__ == '__main__':
    app.run(host='0.0.0.0', port='5000')